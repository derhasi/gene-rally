Hasi's ROC - Race of Champions
==============================
by derhasi [derhasi@web.de]


In multiplayer you have the option to race on the same side of the track or one can use the other side (like in the famous Race of Champions on Gran Canaria)